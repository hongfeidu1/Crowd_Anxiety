using System.Collections;
using System.Collections.Generic;
using System.Security.Cryptography;
using UnityEngine;

//ͨ�ص㣬�������������Collider2D,��ѡis Trigger
public class LevelGoal : MonoBehaviour
{
    [Header("LevelController")]
    [Tooltip("GameObject")]
    public LevelController levelController;

    private void Reset()
    {
        var col = GetComponent<Collider2D>();
        if (col != null)
            col.isTrigger = true;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
            return;
        if (levelController != null)
            levelController.ClearLevel();
    }
}
