using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PressureBarUI : MonoBehaviour
{
    [Header("���ݽű�")]
    public PressureSystem pressureSystem;

    [Header("����")]
    [Tooltip("��ֱ�������Image �� Type ������ Filled��Fill Method = Vertical��Fill Origin = Bottom")]
    public Image fill;

    [Header("�̶���")]
    [Tooltip("�׶ζ�")]
    public RectTransform stage2Maker;
    [Tooltip("�׶���")]
    public RectTransform stage3Maker;

    private void Awake()
    {
        if (fill != null && fill.type != Image.Type.Filled)
            Debug.LogWarning("PressureBarUI��Fill �� Image Type ���� Filled��fillAmount ������Ч", fill);

        PlaceMakers();
    }

    private void Update()
    {
        if (pressureSystem == null || fill == null)
            return;

        fill.fillAmount = Mathf.Clamp01(pressureSystem.Pressure);
    }

    private void OnValidate()
    {
        PlaceMakers();
    }

    private void PlaceMakers()
    {
        PlaceMaker(stage2Maker, pressureSystem.stage2Threshold);
        PlaceMaker(stage3Maker, pressureSystem.stage3Threshold);
    }

    private void PlaceMaker(RectTransform maker, float t)
    {
        if(maker == null) return;

        maker.anchorMin = new Vector2(0.5f, t);
        maker.anchorMax = new Vector2(0.5f, t);
        maker.anchoredPosition = Vector2.zero;
    }
}
