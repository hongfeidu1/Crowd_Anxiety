using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

//��Ұ����
//��ѹ��ֵ�ӵ����������
public class TensionVisualController : MonoBehaviour
{
    [Header("����Դ")]
    [Tooltip("PressureSystem")]
    public PressureSystem pressureSystem;

    [Header("Volume")]
    [Tooltip("TensionVolumeProfile")]
    public VolumeProfile profile;

    [Header("Vignette:ǿ��")]
    [Tooltip("��ʼֵ")]
    [Range(0f, 1f)] public float instensityClam = 0.2f;
    [Tooltip("��ѹ��")]
    [Range(0f, 1f)] public float instensityTense = 0.8f;

    [Header("Vignette:����Ӳ��")]
    [Tooltip("��ʼֵ")]
    [Range(0f, 1f)] public float smoothnessClam = 0.4f;
    [Tooltip("��ѹ��")]
    [Range(0f, 1f)] public float smoothnessTense = 0.6f;

    [Header("�׶�ԾǨ���")]
    [Tooltip("Խ����ֵ��˲ʱ����")]
    [Range(0f, 0.5f)] public float punchStrength = 0.2f;
    [Tooltip("���˥��ʱ��/s")]
    [Range(0.1f, 2f)] public float punchDuration = 0.5f;

    [Header("ɫ�� Chromatic Aberration")]
    [Tooltip("��ʼɫ��")]
    [Range(0f, 1f)] public float aberrationClam = 0f;
    [Tooltip("��ɫ��")]
    [Range(0f, 1f)] public float aberrationTense = 0.2f;

    [Header("���")]
    [Range(0f, 1f)] public float grainClam = 0f;
    [Range(0f, 1f)] public float grainTense = 0.3f;

    private Vignette vignette;
    private ChromaticAberration chromaticAberration;
    private FilmGrain filmGrain;

    private int lastStage = 1;
    private float punchTimer;

    private void Awake()
    {
        if(profile == null)
        {
            Debug.LogError("TensionVisualController:û��ָ��Volume Profile", this);
            return;
        }
        if(!profile.TryGet(out vignette))
        {
            Debug.LogError("TensionVisualController:Profile û������Vignette override", this);
        }
        if(!profile.TryGet(out chromaticAberration))
        {
            Debug.LogWarning("TensionVisualController:Profile û��Chromatic Aberration", this);
        }
        if (!profile.TryGet(out filmGrain))
            Debug.LogWarning("TensionVisualController:Profile û��Film Grain", this);

        vignette.intensity.overrideState = true;
        vignette.smoothness.overrideState = true;
        chromaticAberration.intensity.overrideState = true;
        filmGrain.intensity.overrideState = true;
    }

    private void Update()
    {
        if (pressureSystem == null || vignette == null) return;
        //ԾǨ
        if (pressureSystem.Stage > lastStage)
        {
            lastStage = pressureSystem.Stage;
            punchTimer = punchDuration;
        }

        float t = Mathf.Clamp01(pressureSystem.Pressure);
        float punch = 0f;
        //˥��
        if (punchTimer > 0f)
        {
            punchTimer -= Time.deltaTime;
            punch = punchStrength * Mathf.Clamp01(punchTimer / punchDuration);
        }

        vignette.intensity.value = Mathf.Clamp01(Mathf.Lerp(instensityClam, instensityTense, t) + punch);
        vignette.smoothness.value = Mathf.Lerp(smoothnessClam, smoothnessTense, t);
        chromaticAberration.intensity.value = Mathf.Clamp01(Mathf.Lerp(aberrationClam, aberrationTense, t) + punch * 0.5f);
        filmGrain.intensity.value = Mathf.Lerp(grainClam, grainTense, t);
    }
}
