using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.SceneManagement;

public class LevelController : MonoBehaviour
{
    [Header("����Դ")]
    [Tooltip("PressureSystem")]
    public PressureSystem pressureSystem;

    [Header("ʧ������")]
    [Tooltip("�ж�ѹ����ֵ")]
    [Range(0f, 1f)] public float failThreshold = 0.95f;
    [Tooltip("��ѹʱ������")]
    public float failDuration = 5f;
    [Tooltip("���س���ǰ�ĺ�������ʱ��")]
    public float failFadeTime = 1f;

    [Header("ͨ��")]
    [Tooltip("ͨ�غ����ʱ��")]
    public float clearFadeTime = 2f;
    [Tooltip("���һ�ط����ĸ�������Build Settings���")]
    public int mainMenuBuildIndex = 0;

    [Header("�¼�")]//����Ч��
    public UnityEvent onLevelCleared;

    private float overThresholdTimer;//��¼��ѹʱ��
    private bool cleared;
    private bool reloading;

    private void Update()
    {
        if (cleared || reloading || pressureSystem == null) return;

        if(pressureSystem.Pressure >= failThreshold)
        {
            overThresholdTimer += Time.deltaTime;
            if (overThresholdTimer >= failDuration)
                Fail();
        }
        else
        {
            overThresholdTimer = 0f;//ѹ��������ֵ����ʱ����
        }
    }

    public void ClearLevel()
    {
        if(cleared) return;
        cleared = true;
        onLevelCleared?.Invoke();//�����¼�����ʱΪ��

        LoadNextLevel();
    }

    private void LoadNextLevel()
    {
        int current = SceneManager.GetActiveScene().buildIndex;
        int next = current + 1;

        if(next < SceneManager.sceneCountInBuildSettings)
        {
            if (ScreenFade.Instance != null)
                ScreenFade.Instance.FadeOutAndLoadScene(next, clearFadeTime);
            else
                SceneManager.LoadScene(next);
        }
        else
        {
            //���һ�ػص����˵�
            if (ScreenFade.Instance != null)
                ScreenFade.Instance.FadeOutAndLoadScene(mainMenuBuildIndex, clearFadeTime);
            else
                SceneManager.LoadScene(mainMenuBuildIndex);
        }
    }

    private void Fail()
    {
        reloading = true;
        overThresholdTimer = 0f;
        int index = SceneManager.GetActiveScene().buildIndex;//��ȡ�������к�

        if(index < 0)
        {
            Debug.LogError("��������Build Settings");
            //��File - Build Settings - Scene In Build
            return;
        }

        if (ScreenFade.Instance != null)
            ScreenFade.Instance.FadeOutAndLoadScene(index, failFadeTime);
        else
            SceneManager.LoadScene(index);
    }
}
